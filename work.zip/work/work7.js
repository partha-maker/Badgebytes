function addLi()
            {
        let partha = document.getElementById("partha").value,
          listNode = document.getElementById('list'),
            liNode = document.createElement("Li"),
           txtNode = document.createTextNode(partha);
            
           liNode.appendChild(txtNode);
           listNode.appendChild(liNode);
            }
            